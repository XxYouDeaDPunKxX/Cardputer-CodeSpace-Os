#include "DiagnosticSerial.h"
#include "CxlWssStream.h"
#include "CloudConfig_private.h"
#include "CaBundle.h"
#include <time.h>
#include <algorithm>
#include <WiFi.h>

CxlWssStream::CxlWssStream() {
  ws_.onEvent([this](WStype_t type,uint8_t* data,size_t size){event(type,data,size);});
  ws_.setReconnectInterval(60000); // CXL owns reconnect: every attempt needs a new handshake.
}

void CxlWssStream::fail(TransportFailure cause) {
  auto current = failure_.load();
  while ((current == TransportFailure::None || current == TransportFailure::Connect) &&
         !failure_.compare_exchange_weak(current,cause)) {}
  failed_=true;
}

void CxlWssStream::event(WStype_t type,uint8_t* data,size_t size) {
  switch(type) {
    case WStype_CONNECTED: connected_=true; failure_=TransportFailure::None; break;
    case WStype_DISCONNECTED: {
      const bool wasConnected=connected_.exchange(false);
      char reason[128]={};
      if(data && size) memcpy(reason,data,std::min(size,sizeof(reason)-1));
      fail(wasConnected?TransportFailure::Disconnected:classifyTransportClose(reason));
      break;
    }
    case WStype_BIN:
      if(fragmented_) fail(TransportFailure::Protocol);
      else if(!rx_.put(data,size)) fail(TransportFailure::RxBlock);
      break;
    case WStype_FRAGMENT_BIN_START:
      if(fragmented_) fail(TransportFailure::Protocol);
      else if(!rx_.put(data,size)) fail(TransportFailure::RxBlock);
      fragmented_=true;
      break;
    case WStype_FRAGMENT:
    case WStype_FRAGMENT_FIN:
      if(!fragmented_) fail(TransportFailure::Protocol);
      else if(!rx_.put(data,size)) fail(TransportFailure::RxBlock);
      if(type==WStype_FRAGMENT_FIN) fragmented_=false;
      break;
    case WStype_TEXT:
    case WStype_FRAGMENT_TEXT_START:
    case WStype_ERROR: fail(TransportFailure::Protocol); break;
    default: break;
  }
}

bool CxlWssStream::connect() {
  claimOwner();
  stop();
  failure_=TransportFailure::Connect;
  if(!tx_) tx_=xQueueCreate(16,sizeof(Packet));
  if(!tx_) return false;
  xQueueReset(tx_);
  failed_=false; fragmented_=false;
  auto progress=[this](ConnectionPhase phase){
    if(!progress_||progress_(phase))return true;
    stop();failed_=true;return false;
  };
  if(!progress(ConnectionPhase::Time))return false;
  // Preserve the network's resolvers for both probes and desktop sessions.
  // An HTTP refusal is not evidence that its DNS should be replaced.
  CSOS_LOGF("[CSOS] dns_policy=network primary=%s secondary=%s\n",
    WiFi.dnsIP(0).toString().c_str(),WiFi.dnsIP(1).toString().c_str());
  CSOS_LOGF("[CSOS] transport_start epoch=%lld heap=%u\n",(long long)time(nullptr),(unsigned)ESP.getFreeHeap());
  // A cold device must acquire valid time before certificate date validation.
  if(time(nullptr)<1767225600) {
    configTime(0,0,"pool.ntp.org","time.cloudflare.com");
    const uint32_t started=millis();
    while(time(nullptr)<1767225600 && millis()-started<20000){
      if(!progress(ConnectionPhase::Time))return false;
      delay(20);
    }
    if(time(nullptr)<1767225600) { CSOS_LOGF("[CSOS] time_sync_failed epoch=%lld\n",(long long)time(nullptr)); failure_=TransportFailure::Clock; failed_=true; return false; }
  }
  CSOS_LOGF("[CSOS] tls_start epoch=%lld bundle_bytes=%u\n",(long long)time(nullptr),(unsigned)sizeof(CSOS_CA_BUNDLE));
  IPAddress endpointAddress;
  if(!progress(ConnectionPhase::Dns))return false;
  const int resolved=WiFi.hostByName(CSOS_WSS_HOST,endpointAddress);
  CSOS_LOGF("[CSOS] endpoint_dns ok=%d address=%s\n",resolved,endpointAddress.toString().c_str());
  if(!progress(ConnectionPhase::Wss))return false;
  ws_.beginSslWithBundle(CSOS_WSS_HOST,443,"/",CSOS_CA_BUNDLE,sizeof(CSOS_CA_BUNDLE),"binary");
  ws_.setReconnectInterval(0);
  ws_.setAuthorization(user_.c_str(),password_.c_str());
  const uint32_t started=millis();
  while(!connected() && !failed_ && millis()-started<15000) {
    if(!progress(ConnectionPhase::Wss))return false;
    service();delay(1);
  }
  if(!progress(ConnectionPhase::Wss))return false;
  if(!connected()) { CSOS_LOGF("[CSOS] wss_failed after_ms=%lu failed_flag=%d\n",(unsigned long)(millis()-started),(int)failed_.load()); stop(); return false; }
  CSOS_LOGF("[CSOS] wss_connected after_ms=%lu\n",(unsigned long)(millis()-started));
  ws_.setReconnectInterval(60000);
  return true;
}

void CxlWssStream::service(bool receive) {
  if(owner_!=xTaskGetCurrentTaskHandle()) { fail(TransportFailure::Owner); return; }
  if(failed_) { ws_.disconnect(); connected_=false; return; }
  Packet packet;
  // TX is serviced even while RX is applying backpressure on a full tile slot.
  for(int i=0;i<16 && connected() && xQueueReceive(tx_,&packet,0)==pdTRUE;i++) {
    if(!ws_.sendBIN(packet.data,packet.size)) { fail(TransportFailure::TxWrite); break; }
    sentCount_++;
  }
  if(receive && !rx_.available() && !failed_) ws_.loop();
}

int CxlWssStream::available() { service(); return connected()?(int)rx_.available():0; }
int CxlWssStream::read(uint8_t* destination,size_t size) {
  if(!available()) return connected()?0:-1;
  return (int)rx_.read(destination,size);
}
size_t CxlWssStream::write(const uint8_t* data,size_t size) {
  if(!connected() || !tx_ || size>sizeof(Packet::data)) return 0;
  Packet packet={}; packet.size=(uint8_t)size;
  if(size) memcpy(packet.data,data,size);
  if(xQueueSend(tx_,&packet,0)!=pdTRUE) { fail(TransportFailure::TxQueue); return 0; }
  queuedCount_++;
  return size;
}
void CxlWssStream::stop() {
  if(owner_ && owner_!=xTaskGetCurrentTaskHandle()) { fail(TransportFailure::Owner); return; }
  ws_.disconnect(); connected_=false; fragmented_=false; rx_.reset();
  if(tx_) xQueueReset(tx_);
}
