"""Refine the complete JPEG rectangles painted during motion, not just dirties."""
import struct


def with_quality_refinement(Session, tile_width=32, tile_height=16):
    class QualitySession(Session):
        def send(self, data):
            if data[:1] == b'T' and len(data) >= 13:
                with self.lock:
                    if self.lowq:
                        x, y, width, height = struct.unpack_from('<HHHH', data, 1)
                        # The upstream merges dirty tiles into larger rectangles.
                        # Their clean gaps are re-encoded too and must not escape
                        # the subsequent sharp pass. Conservatively include sharp
                        # rectangles sent while a refinement is already pending.
                        right = min((self.ow+tile_width-1)//tile_width,
                                    (x+width+tile_width-1)//tile_width)
                        bottom = min((self.oh+tile_height-1)//tile_height,
                                     (y+height+tile_height-1)//tile_height)
                        if width and height:
                            self.lowq.update((col, row)
                                for row in range(y//tile_height, bottom)
                                for col in range(x//tile_width, right))
            return super().send(data)

    return QualitySession
