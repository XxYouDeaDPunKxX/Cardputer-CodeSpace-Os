# CS OS · November 6 video performance test

The client at this milestone delivered 15.88–15.97 FPS across four measurement windows of about 20 seconds each, using the same animated scene with FAST and SHARP modes and MAX versus a limit of 30. Remote audio was disabled. The test used V2 wiring, ESP32 3.3.2, M5GFX 0.2.23, and M5Unified 0.2.17.

The sketch comes from the compiled snapshot. The CXL server and WSS launcher match the SHA-256 values in the test dossier. The other server modules come from the revision containing those two files. The included desktop profile is the reconstructed CS OS profile that can be applied by the shared setup. The exact desktop profile used in the measured session is not established. The setup also applies XFWM artifact-mitigation settings documented on November 7, **after** the FPS measurements. The known XFCE baseline for this period used 640 × 480, 120 DPI, Greybird-accessibility window decorations, a 40 px panel with 24 px icons, and 12 px scrollbars.

To build and install this version, follow the [setup guide](docs/SETUP.md) and the [V2 wiring diagram](docs/CABLAGGIO-V2.md). The normal build disables the probe. To recreate FPS instrumentation, build with `-FpsProbe` and create `/workspaces/.csos-smoke/fps-probe.enabled` before starting the CXL service. Remove the marker after testing and restart CXL.

Use [V2 wiring](docs/CABLAGGIO-V2.md) for this package. The Cardputer and Codespaces desktop retain their original interface labels.
