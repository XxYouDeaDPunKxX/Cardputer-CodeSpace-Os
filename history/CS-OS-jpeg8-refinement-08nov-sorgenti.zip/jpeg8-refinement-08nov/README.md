# CS OS · November 8 JPEG8 and sharpness refinement

Increasing the client's JPEG limit from 4 to 8 KiB improved video in the hands-on test. With the same firmware, a later server correction restored sharpness after moving windows. Interactive JPEG retains its 8 KiB budget, while refinement uses a separate 4 KiB-per-cycle budget. CXL v5 audio at 12 kHz remained intermittent.

The client comes from the JPEG8 source snapshot, whose identity was corroborated by a flash backup, and targets V2 wiring. It uses ESP32 core 3.2.1, M5GFX 0.2.15, and M5Unified 0.2.10. The CXL, quality, video, and audio modules match the SHA-256 values from deployment. This package uses the normal WSS launcher without the experiment observer and a desktop profile reconstructed through the shared setup. These reconstructed components have a different provenance from the launcher and desktop state in the original test.

To build and install this version, follow the [setup guide](docs/SETUP.md) and [V2 wiring diagram](docs/CABLAGGIO-V2.md). The console and probes are disabled in the normal build.

Use [V2 wiring](docs/CABLAGGIO-V2.md) for this package. The Cardputer and Codespaces desktop retain their original interface labels.
