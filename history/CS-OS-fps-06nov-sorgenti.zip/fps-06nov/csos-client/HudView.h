#pragma once
#include "LocalControls.h"
#include "AppNavigationLabels.h"
constexpr int GUIDE_PAGES=LOCAL_GUIDE_PAGES;
inline const char* hudMainLabel(int i){return appToolLabel(i);}
inline const char* hudSystemLabel(int i){static const char* const a[]={"Verifica collegamenti","Modifica accesso","Diagnostica","Luce interna","Limite FPS","Qualita","Cursore","Monitor successivo","Aggiorna immagine","Disconnetti"};return i>=0&&i<10?a[i]:nullptr;}
inline const char* hudMenuLabel(int page,int row){return row>=0&&row<3?hudMainLabel(page+row):nullptr;}
inline const char* hudGuideLine(int page,int row){
 static const char* const a[GUIDE_PAGES][3]={
 {"Leggere la guida","Su/giu: argomento. Invio o sinistra/destra: testo. Esc: indietro. Opt chiude.","TFT prima di Linux, HUD durante Linux. I due indici indicano argomento e parte. Nei menu i tasti non scrivono a Linux."},
 {"Avvio e sessione","Wi-Fi noto e controlli automatici. Apri desktop collega quando CXL e pronto. Durante il collegamento Esc, Opt o Annulla richiedono la chiusura; attesa visibile fino al rilascio.","Avvia solo con Codespace fermo verificato. Stato ignoto non significa macchina spenta. R ricontrolla, non avvia. Triangoli seguono i pulsanti; Tab scorre, Invio attiva."},
 {"Reti Wi-Fi","Rete: cerca, scegli, inserisci la password. R cerca ancora. Otto profili salvati, recupero automatico.","Nome manuale e Dimentica rete sono nello stesso elenco. Nuova rete salvata dopo connessione riuscita; durante Linux le modifiche valgono al prossimo collegamento."},
 {"Accessi distinti","Wi-Fi: password rete. GitHub: nome macchina e token. WSS: utente/password ponte. CXL: codice desktop.","Editor: Invio accetta, Opt annulla, Tab mostra/nasconde password. Conferma salva; controlla l'esito. La sessione aperta mantiene i suoi accessi."},
 {"Tasti e modificatori","Opt breve: Scrivi/Controlla; tieni 1s: impostazioni. Cambiare rilascia input e drag, conserva zoom e pan.","Scrivi invia tasti a Linux. Fn e Aa sono interruttori. Aa ricorda separatamente Shift in Scrivi e precisione in Controlla. Ctrl/Alt: prossimo tasto/tocco; secondo tap annulla; tenuti restano premuti."},
 {"Fn e Linux","In Scrivi, Fn acceso: 1..9 > F1..F9, 0 > F10, - > F11, = > F12; triangoli > direzioni; [ ] > PagSu/Giu. H Home, E End, I Insert, P Stampa, M Menu, del Delete. Esc invia Escape; Fn spento scrive `.","Fn acceso, poi Tab prepara Super; secondo Tab annulla, tenuto mantiene Super. Fn resta acceso: spegnilo per scrivere normalmente."},
 {"Puntatore","Triangoli: puntatore, senza Fn. Aa: precisione. Invio: sinistro al rilascio; tenuto 0,6s: destro al rilascio. [ ]: rotella.","Spazio: aggancia/rilascia drag; Esc rilascia, stessa tab. Drag sospende pennino e click Invio. Apostrofo: centrale; \\: destro tenuto. Per scrivere passa a Scrivi."},
 {"Vista","In Controlla, EASD sposta vista e puntatore. I triangoli muovono il mouse; continuando al bordo scorre la vista. - =: zoom. [ ]: rotella. Tab: intera/nativa.","Pennino attivo in entrambi gli assetti. F avvia Sposta finestra: i triangoli arancioni muovono, Invio fissa, esc annulla. Durante drag EASD non sposta la vista; i triangoli trascinano."},
 {"Pennino","Tap: sinistro; fermo 0,6s: destro nel punto toccato. Assoluto, non trackpad. Per trascinare: Controlla e Spazio. Pennino consigliato per i bordi.","Ctrl/Alt/Super preparati valgono per click, pennino e drag. Aa ricorda il proprio stato per assetto. Touch remoto sospeso nei menu, nel drag e con TFT spento. Offline il pennino agisce sui controlli locali."},
 {"Opzioni e immagine","Opt tenuto apre, tap chiude; su/giu sceglie, Invio apre, Esc torna. Durante Linux le opzioni restano nell'HUD e il desktop sul TFT.","Regola schermi: luci, FPS, qualita, cursore, monitor e aggiorna immagine. SRV rispetta il server; MAX rimuove il limite. Codespace include Super singolo/prossimo tasto. Audio remoto non disponibile."},
 {"Luci e memoria","Regola schermi: apri una luce, sinistra/destra regola del 10%, Esc torna. Limiti 10% e 100%. Luci, Qualita e FPS si salvano da soli. Errore: il nuovo valore non e confermato per il riavvio.","TFT: spegni oscura, non chiude Linux. Per riaccendere: Opt tenuto > Regola schermi > TFT: accendi, oppure cambia Luce esterna. Offline spegnimento bloccato. Oscuramento temporaneo."},
 {"Diagnosi e recupero","Diagnostica: Wi-Fi, GitHub, CXL. CPU e memoria sono del Cardputer, non del Codespace. Stato / riprova verifica, non avvia. WSS 404 non prova Codespace fermo.","401/403: origine non provata, controlla l'accesso interessato e la causa verificata. Caduta della sessione: pre-desktop, ricontrolla e premi Entra quando pronto."},
 {"Chiudere Linux","Disconnetti lascia Linux acceso; Arresta chiude con conferma. Spegnere il Cardputer non ferma subito Codespace. La presenza mantiene attivo l'host entro i limiti GitHub.","Stop/start conserva il disco, non finestre e processi. Rebuild/eliminazione possono perdere app e file. Storage consumato anche da spento; quota finita non significa cancellazione."}
 };
 return page>=0&&page<GUIDE_PAGES&&row>=0&&row<3?a[page][row]:nullptr;
}

inline const char* hudCommandLabel(LocalCommand command){
 switch(command){
 case LocalCommand::OpenGuide:return "Guida ai comandi";case LocalCommand::OpenDiagnostics:return "Diagnostica";
 case LocalCommand::Retry:return "Verifica collegamenti";case LocalCommand::Configure:return "Accesso desktop";
 case LocalCommand::Wifi:return "Reti Wi-Fi";case LocalCommand::Management:return "GitHub / Codespace";
 case LocalCommand::Start:return "Avvia Codespace";case LocalCommand::Stop:return "Arresta Codespace";
 case LocalCommand::Disconnect:return "Disconnetti";
 case LocalCommand::SuperTap:return "Tasto Super";case LocalCommand::SuperNext:return "Prepara Super";
 case LocalCommand::Fps:return "Limite FPS";case LocalCommand::Quality:return "Qualita";
 case LocalCommand::Cursor:return "Cursore";case LocalCommand::Monitor:return "Monitor successivo";
 case LocalCommand::Refresh:return "Aggiorna immagine";case LocalCommand::Brightness:return "Luce interna";
 case LocalCommand::ExternalBrightness:return "Luce esterna";case LocalCommand::ExternalLight:return "TFT: spegni";
 case LocalCommand::Telemetry:return "Stato Cardputer";case LocalCommand::Info:return "Informazioni";
 default:return "Comando";}
}

// Action descriptions share the real command identifiers; no new commands.
inline const char* hudCommandHint(LocalCommand command){
 switch(command){
 case LocalCommand::OpenGuide:return "Tastiera, pennino e comandi del desktop";
 case LocalCommand::OpenDiagnostics:return "Stato attuale e problemi registrati";
 case LocalCommand::SuperTap:return "Invia il tasto Super a Linux";
 case LocalCommand::SuperNext:return "Super vale per il prossimo tasto o click";
 case LocalCommand::Retry:return "Ricontrolla rete, macchina e desktop";
 case LocalCommand::Configure:return "Credenziali del ponte WSS e codice CXL";
 case LocalCommand::Wifi:return "Scegli, salva o dimentica una rete";
 case LocalCommand::Management:return "Nome Codespace e token GitHub";
 case LocalCommand::Start:return "Avvia la macchina, poi verifica il desktop";
 case LocalCommand::Stop:return "Ferma macchina e processi";
 case LocalCommand::Disconnect:return "Chiude il desktop sul Cardputer";
 case LocalCommand::Brightness:case LocalCommand::ExternalBrightness:return "Apri la regolazione; sinistra e destra: 10%";
 case LocalCommand::ExternalLight:return "Solo in sessione; il menu resta acceso";
 case LocalCommand::Fps:return "Cambia limite; SRV usa quello del server";
 case LocalCommand::Quality:return "Regola la qualita dello streaming";
 case LocalCommand::Cursor:return "Mostra o nasconde il puntatore remoto";
 case LocalCommand::Monitor:return "Passa al monitor remoto successivo";
 case LocalCommand::Refresh:return "Richiede una nuova immagine completa";
 case LocalCommand::Telemetry:return "Misure del dispositivo e della rete";
 case LocalCommand::Info:return "Dispositivo e calibrazione del pennino";
 default:return "Invio: apri; Esc: indietro";
 }
}

inline int hudGuideKey(int topic,int item){
 // Physical matrix IDs, checked against the operator's sticker photograph.
 static const int keys[GUIDE_PAGES][3]={{39,53,41},{41,43,-1},{43,41,-1},{41,43,14},{43,29,28},{28,14,0},{41,55,29},{11,12,14},{-1,-1,-1},{43,41,0},{43,41,-1},{-1,-1,-1},{43,41,0}};
 return topic>=0&&topic<GUIDE_PAGES&&item>=0&&item<3?keys[topic][item]:-1;
}
