#pragma once
#include "PhysicalKeys.h"
#include "AppNavigationLabels.h"
#ifdef ARDUINO
#include <lgfx/Fonts/Font32rle.h>
#else
#ifndef PROGMEM
#define PROGMEM
#define CSOS_UNDEFINE_PROGMEM
#endif
#include "../vendor/fonts/Font32rle.h"
#ifdef CSOS_UNDEFINE_PROGMEM
#undef PROGMEM
#undef CSOS_UNDEFINE_PROGMEM
#endif
#endif
// Shared presentation and geometry for the live controller and host preview.
struct AppRect { int x,y,w,h; bool contains(int px,int py)const{return px>=x&&py>=y&&px<x+w&&py<y+h;} };
struct AppViewCache { bool painted=false; String keys[12]; void invalidate(){painted=false;} };
template<class D> bool appRegion(D& d,AppViewCache& c,int slot,AppRect r,const String& key){
 if(c.painted&&c.keys[slot]==key)return false;
 c.keys[slot]=key;d.fillRect(r.x,r.y,r.w,r.h,UiPalette::Background);return true;
}
template<class D> void appText(D& d,int x,int y,const String& text,float size=.8f,uint16_t color=UiPalette::Ink,uint16_t bg=UiPalette::Background){
 d.setFont(&fonts::Font4);d.setTextWrap(false);d.setTextSize(size,size);d.setTextColor(color,bg);d.setCursor(x,y);d.print(text);
}
template<class D> void appOutline(D& d,AppRect r,uint16_t color){
 d.drawFastHLine(r.x,r.y,r.w,color);d.drawFastHLine(r.x,r.y+r.h-1,r.w,color);
 d.drawFastVLine(r.x,r.y,r.h,color);d.drawFastVLine(r.x+r.w-1,r.y,r.h,color);
}
namespace AppColors {
constexpr uint16_t Surface=UiPalette::from332(0x29), Focus=UiPalette::from332(0x4a);
constexpr uint16_t Action=UiPalette::from332(0x7e), Yellow=UiPalette::from332(0xfc);
}
template<class D> void appSurface(D& d,AppRect r,uint16_t color){
 d.fillRect(r.x+2,r.y,r.w-4,1,color);
 d.fillRect(r.x+1,r.y+1,r.w-2,1,color);
 d.fillRect(r.x,r.y+2,r.w,r.h-4,color);
 d.fillRect(r.x+1,r.y+r.h-2,r.w-2,1,color);
 d.fillRect(r.x+2,r.y+r.h-1,r.w-4,1,color);
}
template<class D> void appChoice(D& d,AppRect r,const String& label,bool selected,bool primary=false,uint16_t accent=AppColors::Action){
 const auto bg=primary?accent:selected?AppColors::Focus:AppColors::Surface;
 if(selected)appSurface(d,r,UiPalette::White);
 const int inset=selected?2:0;
 appSurface(d,{r.x+inset,r.y+inset,r.w-inset*2,r.h-inset*2},bg);
 float size=r.w<170?.72f:.80f;
 d.setFont(&fonts::Font4);d.setTextSize(size,size);
 if(d.textWidth(label)>r.w-12){size=.65f;d.setTextSize(size,size);}
 appText(d,r.x+(r.w-d.textWidth(label))/2,r.y+(r.h-int(26*size))/2,label,size,
         primary?UiPalette::KeyInk:UiPalette::Ink,bg);
}
inline AppRect appHomePrimary(){return {8,174,179,40};}
inline AppRect appHomeManage(){return {197,174,115,40};}
inline AppRect appToolRow(int row){return {8+155*(row%2),47+66*(row/2),149,55};}
enum class AppArrival:uint8_t {Ready,Offline,Stopped,Starting,AccessError,Checking,Waiting,Connecting,Cancelling,WifiChanging,WifiRestoring,Request,RateWait};
struct AppHomeView {AppArrival phase=AppArrival::Ready;bool manageSelected=false,fault=false,recoverable=false,wifiConnected=false;uint32_t waitSeconds=0;String network,machine,desktop,notice;};
template<class D> void drawAppHome(D& d,const AppHomeView& s,AppViewCache& c){
 using namespace UiPalette;
 if(!c.painted)d.fillScreen(Background);
 if(appRegion(d,c,0,{0,0,320,66},"home")){
  appText(d,12,8,"CS OS",.67f,AppColors::Action);
  appText(d,12,30,"Accesso al desktop",1.02f);
 }
 const int phase=int(s.phase);
 const bool error=s.phase==AppArrival::AccessError;
 const String network=s.wifiConnected?(s.network.length()?s.network:String("Connessa")):
                      s.phase==AppArrival::WifiChanging?String("Cambio rete in corso"):
                      s.phase==AppArrival::WifiRestoring?String("Ripristino in corso"):String("Scollegata");
 const String values[]={network,s.machine.length()?s.machine:String("Da verificare"),
                        s.desktop.length()?s.desktop:String("Da verificare")};
 const char* labels[]={"Wi-Fi","Codespace","Desktop"};
 for(int row=0;row<3;++row){
  const int y=68+row*26;
  if(!appRegion(d,c,4+row,{0,y,320,25},values[row]+":"+String(phase)))continue;
  appText(d,12,y+2,labels[row],.70f,Muted);
  const uint16_t color=row==0&&!s.wifiConnected?AppColors::Yellow:row==2&&error?AppColors::Yellow:Ink;
  d.setClipRect(116,y,193,23);
  appText(d,116,y+2,values[row],.70f,color);
  d.clearClipRect();
 }
 const String notice=s.fault?String("Evento registrato in Diagnostica"):s.notice;
 if(appRegion(d,c,1,{0,146,320,22},notice)){
  d.setClipRect(12,146,296,20);
  appText(d,12,147,notice,.63f,s.fault?AppColors::Yellow:Muted);
  d.clearClipRect();
 }
 if(appRegion(d,c,2,{0,168,320,72},String(phase)+":"+String(s.manageSelected)+":"+String(s.waitSeconds)+String(s.recoverable))){
  const char* actions[]={"Apri desktop","Scegli rete","Avvia Codespace","Avvio in corso","Verifica accessi","Verifica stato","Verifica desktop","Annulla collegamento","Chiusura in corso","Annulla cambio rete","Ripristino in corso","Verifica stato","Verifica rinviata"};
  const bool blocked=s.phase==AppArrival::Starting||s.phase==AppArrival::Cancelling||s.phase==AppArrival::WifiRestoring||
                     s.phase==AppArrival::RateWait||(s.phase==AppArrival::Request&&!s.recoverable);
  if(s.phase==AppArrival::RateWait)appText(d,12,183,String("Attendi ")+String(s.waitSeconds)+" s",.85f,AppColors::Yellow);
  else if(blocked)appText(d,12,183,s.phase==AppArrival::Request?"Verifica esito":s.phase==AppArrival::Cancelling?"Annullamento in corso":actions[phase],.76f,Muted);
  else appChoice(d,appHomePrimary(),actions[phase],!s.manageSelected,true,error?AppColors::Yellow:AppColors::Action);
  const bool cancellable=s.phase==AppArrival::Connecting||s.phase==AppArrival::WifiChanging;
  const bool manage=s.phase!=AppArrival::WifiRestoring&&s.phase!=AppArrival::Cancelling&&!cancellable;
  if(manage){
   appChoice(d,appHomeManage(),"",s.manageSelected);
   const auto manageBg=s.manageSelected?AppColors::Focus:AppColors::Surface;
   paintPhysicalKey(d,UI_OPT,202,182,30,22);
   appText(d,237,184,"Gestisci",.65f,Ink,manageBg);
   if(!blocked){
    paintPhysicalKey(d,UI_UP,8,218,19,18);paintPhysicalKey(d,UI_DOWN,29,218,19,18);
    appText(d,54,219,"Scegli",.62f,Muted);
    paintPhysicalKey(d,UI_ENTER,113,216,25,23);appText(d,143,219,"Apri",.62f,Muted);
   }
   appText(d,204,218,"R",.72f,Ink);appText(d,223,219,"Verifica",.62f,Muted);
  }else if(cancellable){
   paintPhysicalKey(d,UI_ESC,9,216,32,22);appText(d,48,219,"Annulla",.66f,Muted);
  }
 }
 c.painted=true;
}
enum class AppPanel:uint8_t {Tools,Networks,Light,AccessError};
struct AppPanelView {AppPanel page=AppPanel::Tools;int selected=0;int value=50;bool external=true,failed=false;};
template<class D> void drawAppPanel(D& d,const AppPanelView& s,AppViewCache& c){
 using namespace UiPalette;const String identity=String(int(s.page))+String(s.external)+String(s.failed);
 if(!c.painted)d.fillScreen(Background);
 if(appRegion(d,c,0,{0,0,320,33},identity)){
  paintPhysicalKey(d,UI_ESC,277,4,35,23);
  const char* names[]={"Impostazioni","Reti Wi-Fi","Luce esterna","Accesso desktop"};
  appText(d,8,4,s.page==AppPanel::Light&&!s.external?"Luce interna":names[int(s.page)],.9f);
 }
 if(appRegion(d,c,1,{0,33,320,174},identity+":"+String(s.selected))){
  c.keys[3]="";
  if(s.page==AppPanel::Tools){
   for(int i=0;i<4;i++)appChoice(d,appToolRow(i),appToolLabel(i),s.selected==i);
   if(s.selected>=0&&s.selected<4)appText(d,10,181,appToolHint(s.selected),.71f,Muted);
  }else if(s.page==AppPanel::Networks){
   appText(d,9,39,"Scegli dove collegarti",.85f);
   const char* names[]={"Casa","Laboratorio","Altra rete..."};
   for(int i=0;i<3;i++){
    const AppRect r={8,73+i*37,304,34};appChoice(d,r,names[i],s.selected==i);
    appText(d,228,r.y+8,i<2?"salvata":"",.65f,Green);
   }
   appText(d,10,187,"Cerca reti   /   Gestisci salvate",.7f,Muted);
  }else if(s.page==AppPanel::Light){
   appText(d,10,43,s.external?"Display esterno":"Display Cardputer",.85f);
   paintPhysicalKey(d,UI_LEFT,8,165,25,24);paintPhysicalKey(d,UI_RIGHT,37,165,25,24);
   appText(d,74,169,"Regola a passi del 10%",.75f);
  }else{
   appText(d,9,42,"Accesso non accettato",1,Warning);
   appText(d,9,79,"Risposta WSS: HTTP 401.",.75f);
   appText(d,9,104,"Verifica l'accesso remoto.",.75f);
   appChoice(d,{8,147,304,38},"Modifica accesso",true,true,Warning);
  }
 }
 if(s.page==AppPanel::Light&&appRegion(d,c,3,{8,73,304,77},identity+":"+String(s.value))){
  appText(d,10,75,String(s.value)+"%",1.7f,s.failed?Warning:Green);
  for(int i=0;i<10;i++)d.fillRect(10+i*30,131,26,15,i<s.value/10?Green:Rule);
 }
 if(appRegion(d,c,2,{0,207,320,33},identity)){
  if(s.page!=AppPanel::Light){paintPhysicalKey(d,UI_UP,8,214,23,20);paintPhysicalKey(d,UI_DOWN,34,214,23,20);}
  appText(d,s.page==AppPanel::Light?10:66,216,s.page==AppPanel::Light?(s.failed?"Salvataggio non riuscito":"Salvataggio automatico"):"Scegli",.65f,s.failed?Warning:Muted);
  if(s.page!=AppPanel::Light){paintPhysicalKey(d,UI_ENTER,222,211,28,24);appText(d,259,216,"Apri",.65f);}
 }
 c.painted=true;
}
template<class D> void drawAppLight(D& d,bool small,bool external,int value,bool failed,AppViewCache& cache){
 using namespace UiPalette;
 if(!small){AppPanelView panel;panel.page=AppPanel::Light;panel.value=value;panel.external=external;panel.failed=failed;drawAppPanel(d,panel,cache);return;}
 if(!cache.painted)d.fillRect(0,0,240,109,Background);
 if(appRegion(d,cache,0,{0,0,240,29},String(external))){
  appText(d,5,2,external?"Luce esterna":"Luce interna",.9f,Green);paintPhysicalKey(d,UI_ESC,203,1,34,24);
 }
 if(appRegion(d,cache,1,{0,30,240,78},String(value)+String(failed))){
  appText(d,6,31,String(value)+"%",1.2f,failed?Warning:Ink);
  for(int i=0;i<10;i++)d.fillRect(94+i*14,40,11,16,i<value/10?Green:Rule);
  paintPhysicalKey(d,UI_LEFT,4,73,26,23);paintPhysicalKey(d,UI_RIGHT,32,73,26,23);
  appText(d,68,76,failed?"Salvataggio fallito":"Regola 10%",.75f,failed?Warning:Ink);
 }cache.painted=true;
}
enum class AppHudPage:uint8_t {Write,Control,Move,Drag,Tools,Guide,Status,Recovery};
struct AppHudView {AppHudPage page=AppHudPage::Control;int zoom=150,selected=0;uint8_t pending=0,held=0;bool precise=false;};
template<class D> void appRail(D& d,AppHudPage page){
 using namespace UiPalette;
 const char* names[]={"SCRIVI","CONTROLLA","FINESTRA","DRAG","STRUMENTI","GUIDA","STATO","RECUPERO"};
 const uint16_t colors[]={from332(0x2a),from332(0x0d),from332(0x69),from332(0x69),AppColors::Focus,Rule,Rule,from332(0x89)};
 const int index=int(page);
 appSurface(d,{1,2,23,103},colors[index]);
 // The same Font4 glyph data drives the rotated label and host rendering.
 const char* label=names[index];
 constexpr int height=12;
 int length=0;
 for(const char* c=label;*c;++c)length+=int(widtbl_f32[*c-32]*.47f);
 int bottom=2+(103+length)/2-1;
 for(const char* c=label;*c;++c){
  const int width=widtbl_f32[*c-32], scaled=int(width*.47f);
  const auto* runs=chrtbl_f32[*c-32];
  for(int y=0;y<height;++y){
   int run=0,end=(runs[0]&127)+1;
   for(int x=0;x<scaled;++x){
    const int pixel=(y*26/height)*width+x*width/scaled;
    while(pixel>=end)end+=(runs[++run]&127)+1;
    if(runs[run]&128)d.fillRect(7+y,bottom-x,1,1,Ink);
   }
  }
  bottom-=scaled;
 }
}
template<class D> void appPanKeys(D& d,int x,int y){
 const char* keys[]={"E","A","S","D"};
 const auto color=AppColors::Action;
 for(int i=0;i<4;++i){
  const int keyX=x+i*26,arrowX=keyX+13,arrowY=y+6;
  appText(d,keyX,y,keys[i],.69f);
  if(i==0)d.fillTriangle(arrowX+3,arrowY,arrowX,arrowY+5,arrowX+6,arrowY+5,color);
  if(i==1)d.fillTriangle(arrowX,arrowY+3,arrowX+5,arrowY,arrowX+5,arrowY+6,color);
  if(i==2)d.fillTriangle(arrowX,arrowY,arrowX+6,arrowY,arrowX+3,arrowY+5,color);
  if(i==3)d.fillTriangle(arrowX+5,arrowY+3,arrowX,arrowY,arrowX,arrowY+6,color);
 }
}
template<class D> void drawAppHudBody(D& d,const AppHudView& s,AppViewCache& c){
 using namespace UiPalette;
 const String identity=String(int(s.page));
 if(appRegion(d,c,1,{0,0,240,109},identity+":"+String(s.selected)+":"+String(s.pending)+":"+String(s.held)+":"+String(s.precise))){
  c.keys[2]="";
  appRail(d,s.page);
  if(s.page==AppHudPage::Tools){
   const char* names[]={"Schermi","Connessioni","Assistenza","Codespace"};
   for(int i=0;i<4;++i)appChoice(d,{29+i%2*105,8+i/2*40,101,35},names[i],s.selected==i);
   appText(d,32,91,String(s.selected+1)+"/4",.58f,Muted);
   paintPhysicalKey(d,UI_ENTER,154,87,26,21);appText(d,184,90,"apri",.62f);
  }else if(s.page==AppHudPage::Write){
   appText(d,31,5,"Tastiera Linux",.94f);
   appText(d,31,33,"Ctrl / Alt",.73f,Blue);
   appText(d,31,53,"Tocca o tieni premuto",.69f);
   paintPhysicalKey(d,UI_FN,31,80,25,23);paintPhysicalKey(d,UI_TAB,60,80,31,23);
   appText(d,97,82,"Super Linux",.72f);
  }else if(s.page==AppHudPage::Move||s.page==AppHudPage::Drag){
   const bool move=s.page==AppHudPage::Move;
   appText(d,31,8,move?"Sposta finestra":"Trascinamento",.88f);
   {
    paintPhysicalKey(d,UI_LEFT,31,42,20,19);paintPhysicalKey(d,UI_UP,52,42,20,19);
    paintPhysicalKey(d,UI_DOWN,73,42,20,19);paintPhysicalKey(d,UI_RIGHT,94,42,20,19);
   }
   paintPhysicalKey(d,move?UI_ENTER:UI_SPACE,30,83,26,23);
   appText(d,59,85,move?"fissa":"rilascia",.71f);
   paintPhysicalKey(d,UI_ESC,132,83,32,23);appText(d,170,85,"annulla",.68f);
  }else{
   appText(d,31,2,"Vista",.63f,AppColors::Action);
   appPanKeys(d,31,18);
   appText(d,140,2,"Puntatore",.63f,AppColors::Yellow);
   paintPhysicalKey(d,UI_UP,139,17,20,19);paintPhysicalKey(d,UI_LEFT,160,17,20,19);
   paintPhysicalKey(d,UI_DOWN,181,17,20,19);paintPhysicalKey(d,UI_RIGHT,202,17,20,19);
   appText(d,31,39,"Zoom",.63f,AppColors::Action);
   paintPhysicalKey(d,11,31,55,21,19);paintPhysicalKey(d,12,54,55,21,19);
   appText(d,140,39,"Rotella",.63f,Blue);
   paintPhysicalKey(d,25,139,55,23,19);paintPhysicalKey(d,26,164,55,23,19);
   paintPhysicalKey(d,UI_TAB,190,55,37,19);
   paintPhysicalKey(d,UI_ENTER,29,83,24,21);appText(d,55,85,"clic",.62f);
   paintPhysicalKey(d,UI_SPACE,88,83,22,21);appText(d,113,85,"drag",.62f);
   appText(d,154,85,s.precise?"Aa fine":"F finestra",.63f);
  }
  if(s.page==AppHudPage::Write||s.page==AppHudPage::Control){
   const int bits[]={1,2,8};
   const char* labels[]={"Ctrl","Alt","Super"};
   for(int i=0;i<3;++i){
    const int bit=bits[i];
    if(!((s.pending|s.held)&bit))continue;
    // Active modifiers move to the relevant command area, leaving room for the rail name.
    appText(d, s.page==AppHudPage::Write?130+i*32:145+i*30,s.page==AppHudPage::Write?34:75,
            labels[i],.46f,s.held&bit?Ink:AppColors::Action,Background);
   }
  }
 }
 if(s.page==AppHudPage::Control&&appRegion(d,c,2,{79,52,56,22},identity+":"+String(s.zoom)))
  appText(d,80,54,s.zoom?String(s.zoom)+"%":String("--"),.66f);
 c.painted=true;
}
